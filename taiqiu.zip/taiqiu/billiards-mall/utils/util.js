/**
 * 工具函数模块
 * 包含日期格式化、金额计算、状态处理等通用工具
 */

/**
 * 日期格式化
 * @param {string|Date} date - 日期
 * @param {string} format - 格式，如 'YYYY-MM-DD HH:mm:ss'
 */
function formatDate(date, format = 'YYYY-MM-DD HH:mm') {
  const d = new Date(date)
  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  const hours = String(d.getHours()).padStart(2, '0')
  const minutes = String(d.getMinutes()).padStart(2, '0')
  const seconds = String(d.getSeconds()).padStart(2, '0')

  return format
    .replace('YYYY', year)
    .replace('MM', month)
    .replace('DD', day)
    .replace('HH', hours)
    .replace('mm', minutes)
    .replace('ss', seconds)
}

/**
 * 相对时间格式化
 * @param {string|Date} date - 日期
 */
function formatRelativeTime(date) {
  const now = new Date()
  const d = new Date(date)
  const diff = now - d

  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)

  if (minutes < 1) return '刚刚'
  if (minutes < 60) return `${minutes}分钟前`
  if (hours < 24) return `${hours}小时前`
  if (days < 7) return `${days}天前`

  return formatDate(date, 'MM-DD HH:mm')
}

/**
 * 格式化时长
 * @param {number} minutes - 分钟数
 */
function formatDuration(minutes) {
  if (minutes < 60) return `${minutes}分钟`
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  if (mins === 0) return `${hours}小时`
  return `${hours}小时${mins}分钟`
}

/**
 * 金额格式化
 * @param {number} amount - 金额（元）
 */
function formatAmount(amount) {
  return `¥${Number(amount).toFixed(2)}`
}

/**
 * 生成订单号
 */
function generateOrderNo() {
  const timestamp = Date.now()
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
  return `T${timestamp}${random}`
}

/**
 * 获取状态文本
 * @param {string} type - 订单类型
 * @param {string} status - 状态码
 */
function getStatusText(type, status) {
  const statusMap = {
    time: {
      pending: '待支付',
      paid: '已支付',
      using: '使用中',
      completed: '已完成',
      cancelled: '已取消'
    },
    product: {
      pending: '待支付',
      paid: '已支付',
      delivered: '待收货',
      completed: '已完成',
      refunded: '已退款'
    }
  }
  return statusMap[type]?.[status] || status
}

/**
 * 获取桌台状态文本
 * @param {string} status
 */
function getTableStatusText(status) {
  const map = {
    available: '空闲',
    occupied: '占用中',
    reserved: '已预约'
  }
  return map[status] || status
}

/**
 * 获取桌台状态颜色
 * @param {string} status
 */
function getTableStatusColor(status) {
  const map = {
    available: '#07c160',
    occupied: '#ee0a24',
    reserved: '#ff976a'
  }
  return map[status] || '#999999'
}

/**
 * 校验手机号
 * @param {string} phone
 */
function validatePhone(phone) {
  return /^1[3-9]\d{9}$/.test(phone)
}

/**
 * 深拷贝
 * @param {any} obj
 */
function deepClone(obj) {
  if (obj === null || typeof obj !== 'object') return obj
  const clone = Array.isArray(obj) ? [] : {}
  for (const key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      clone[key] = deepClone(obj[key])
    }
  }
  return clone
}

/**
 * 节流函数
 * @param {Function} fn - 执行函数
 * @param {number} delay - 延迟毫秒
 */
function throttle(fn, delay = 300) {
  let timer = null
  return function (...args) {
    if (timer) return
    timer = setTimeout(() => {
      fn.apply(this, args)
      timer = null
    }, delay)
  }
}

/**
 * 防抖函数
 * @param {Function} fn - 执行函数
 * @param {number} delay - 延迟毫秒
 */
function debounce(fn, delay = 300) {
  let timer = null
  return function (...args) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(this, args)
    }, delay)
  }
}

module.exports = {
  formatDate,
  formatRelativeTime,
  formatDuration,
  formatAmount,
  generateOrderNo,
  getStatusText,
  getTableStatusText,
  getTableStatusColor,
  validatePhone,
  deepClone,
  throttle,
  debounce
}

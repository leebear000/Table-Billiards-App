/**
 * API 服务模块
 * 已同步后端云函数接口
 */

const app = getApp()
const { generateOrderNo } = require('../utils/util.js')

// API 配置
const API_CONFIG = {
  useCloud: false,  // 是否使用云函数
  mockDelay: 300  // mock 延迟（毫秒）
}

// Mock 数据
const mockData = {
  // 桌台列表
  tables: [
    { id: 'T001', name: '1号台', type: 'standard', status: 'available', pricePerHour: 30 },
    { id: 'T002', name: '2号台', type: 'standard', status: 'occupied', pricePerHour: 30 },
    { id: 'T003', name: '3号台', type: 'standard', status: 'available', pricePerHour: 30 },
    { id: 'T004', name: '4号台', type: 'snooker', status: 'available', pricePerHour: 50 },
    { id: 'T005', name: '5号台', type: 'snooker', status: 'reserved', pricePerHour: 50 },
    { id: 'T006', name: 'VIP1', type: 'VIP', status: 'available', pricePerHour: 80 }
  ],

  // 球杆列表
  cues: [
    { id: 'C001', name: '入门级球杆', brand: 'LP', type: 'purchase', price: 199, deposit: 0, stock: 20 },
    { id: 'C002', name: '进阶球杆', brand: '飞利', type: 'purchase', price: 599, deposit: 0, stock: 10 },
    { id: 'C003', name: '专业球杆', brand: '美洲豹', type: 'purchase', price: 1299, deposit: 0, stock: 5 },
    { id: 'C004', name: '普通租赁球杆', brand: '通用', type: 'rent', price: 10, deposit: 50, stock: 30 },
    { id: 'C005', name: '高级租赁球杆', brand: '美洲豹', type: 'rent', price: 30, deposit: 200, stock: 10 }
  ],

  // 会员卡套餐
  memberPackages: [
    { id: 'P001', name: '月卡', price: 299, duration: 30, benefits: ['9折优惠', '优先预约'], giftBalance: 50, giftPoints: 100 },
    { id: 'P002', name: '季卡', price: 799, duration: 90, benefits: ['8.5折优惠', '优先预约', '免费租杆'], giftBalance: 150, giftPoints: 300 },
    { id: 'P003', name: '年卡', price: 2599, duration: 365, benefits: ['8折优惠', '优先预约', '免费租杆', '专属储物柜'], giftBalance: 500, giftPoints: 1000 }
  ],

  // 订单
  timeOrders: [],
  productOrders: [],

  // 会员信息
  memberInfo: null
}

// 当前会话（开台会话）
let currentSession = null

/**
 * 模拟请求延迟
 */
function mockRequest(data) {
  return new Promise(resolve => {
    setTimeout(() => resolve(data), API_CONFIG.mockDelay)
  })
}

/**
 * 获取 openid
 */
function getOpenId() {
  return app.globalData.openId || 'mock_openid'
}

// ============ 登录服务 ============
const loginService = {
  /**
   * 微信登录
   * @param {object} userInfo - 用户信息 { nickname, avatarUrl }
   */
  async login(userInfo = {}) {
    if (API_CONFIG.useCloud) {
      try {
        // 获取微信 code
        const { code } = await wx.login()
        // 调用云函数
        const res = await wx.cloud.callFunction({
          name: 'login',
          data: {
            code,
            openid: getOpenId(),
            nickname: userInfo.nickname || '',
            avatarUrl: userInfo.avatarUrl || ''
          }
        })
        if (res.result?.success) {
          app.globalData.openId = res.result.openid
          app.globalData.isLoggedIn = true
        }
        return res.result || res
      } catch (err) {
        console.warn('云函数调用失败，使用mock:', err)
        app.globalData.openId = 'mock_openid_' + Date.now()
        app.globalData.isLoggedIn = true
        return { success: true, mock: true }
      }
    }
    app.globalData.openId = 'mock_openid_' + Date.now()
    return { success: true, mock: true }
  }
}

// ============ 桌台服务 ============
const tableService = {
  /**
   * 获取桌台列表
   * @param {string} type - 可选：standard/snooker/VIP
   */
  async getTableList(type) {
    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'getTables',
          data: { type }
        })
        return res.result || res
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }
    let tables = mockData.tables
    if (type) {
      tables = tables.filter(t => t.type === type)
    }
    return mockRequest({ success: true, data: tables })
  },

  /**
   * 获取桌台详情
   */
  async getTableDetail(tableId) {
    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'getTables',
          data: {}
        })
        if (res.result?.data) {
          const table = res.result.data.find(t => t.id === tableId)
          return { success: true, data: table }
        }
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }
    const table = mockData.tables.find(t => t.id === tableId)
    return mockRequest({ success: true, data: table })
  },

  /**
   * 开台
   * @param {object} params - { tableId, minutes, payMethod }
   */
  async openTable(params) {
    const { tableId, minutes, payMethod = 'wechat' } = params

    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'openTable',
          data: {
            openid: getOpenId(),
            table_id: tableId,
            minutes,
            pay_method: payMethod
          }
        })
        if (res.result?.need_pay) {
          // 需要调起支付
          await wx.requestPayment({
            ...res.result.payment
          })
        }
        currentSession = res.result?.session_id
        return res.result
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }

    // Mock 实现
    const table = mockData.tables.find(t => t.id === tableId)
    if (!table) return { success: false, error: '桌台不存在' }

    const amount = Math.round(table.pricePerHour * minutes / 60 * 100) // 分
    const order = {
      id: 'O' + Date.now(),
      orderNo: generateOrderNo(),
      tableId,
      tableName: table.name,
      minutes,
      amount: amount / 100,
      status: 'using',
      startTime: new Date().toISOString(),
      createTime: new Date().toISOString()
    }

    mockData.timeOrders.push(order)
    table.status = 'occupied'
    currentSession = order.id

    return { success: true, data: order, session_id: order.id }
  },

  /**
   * 结账
   * @param {string} sessionId - 会话ID
   */
  async closeTable(sessionId) {
    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'closeTable',
          data: {
            openid: getOpenId(),
            session_id: sessionId || currentSession
          }
        })
        currentSession = null
        return res.result || res
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }

    // Mock 实现
    const order = mockData.timeOrders.find(o => o.id === (sessionId || currentSession))
    if (order) {
      order.status = 'completed'
      order.endTime = new Date().toISOString()
      const table = mockData.tables.find(t => t.id === order.tableId)
      if (table) table.status = 'available'
      currentSession = null
    }
    return { success: true, data: order }
  }
}

// ============ 订单服务 ============
const orderService = {
  /**
   * 获取订单列表
   * @param {string} type - all/session/product
   * @param {string} status - all/pending/paid/completed
   */
  async getOrders(type = 'all', status = 'all') {
    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'getOrders',
          data: {
            openid: getOpenId(),
            type,
            status,
            page: 1,
            page_size: 20
          }
        })
        return res.result || res
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }

    let orders = []
    if (type === 'all' || type === 'session') {
      orders = [...orders, ...mockData.timeOrders]
    }
    if (type === 'all' || type === 'product') {
      orders = [...orders, ...mockData.productOrders]
    }

    if (status !== 'all') {
      orders = orders.filter(o => o.status === status)
    }

    return mockRequest({ success: true, data: orders })
  },

  /**
   * 获取时长订单
   */
  async getTimeOrders() {
    return this.getOrders('session')
  },

  /**
   * 获取商品订单
   */
  async getProductOrders() {
    return this.getOrders('product')
  },

  /**
   * 结账（时长订单）
   */
  async checkout(orderId) {
    return tableService.closeTable(orderId)
  },

  /**
   * 创建商品订单
   */
  async createProductOrder(params) {
    const { productId, quantity = 1, type = 'buy', rentHours = 1 } = params

    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'createOrder',
          data: {
            openid: getOpenId(),
            product_id: productId,
            quantity,
            type,
            rent_hours: type === 'rent' ? rentHours : undefined,
            pay_method: 'wechat'
          }
        })
        if (res.result?.need_pay) {
          await wx.requestPayment({
            ...res.result.payment
          })
        }
        return res.result
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }

    // Mock 实现
    const cue = mockData.cues.find(c => c.id === productId)
    if (!cue) return { success: false, error: '商品不存在' }

    const rentPrice = type === 'rent' ? cue.price * rentHours : 0
    const totalAmount = (type === 'purchase' ? cue.price : rentPrice) + (type === 'rent' ? cue.deposit : 0)

    const order = {
      id: 'P' + Date.now(),
      orderNo: generateOrderNo(),
      productId,
      productName: cue.name,
      type,
      quantity,
      amount: totalAmount,
      rentHours: type === 'rent' ? rentHours : undefined,
      deposit: type === 'rent' ? cue.deposit : undefined,
      status: 'paid',
      createTime: new Date().toISOString()
    }

    mockData.productOrders.push(order)
    return { success: true, data: order }
  }
}

// ============ 球杆服务 ============
const cueService = {
  /**
   * 获取球杆列表
   * @param {string} type - purchase/rent
   */
  async getCueList(type) {
    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'getCueList',
          data: { type }
        })
        return res.result || res
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }

    let cues = mockData.cues
    if (type) {
      cues = cues.filter(c => c.type === type)
    }
    return mockRequest({ success: true, data: cues })
  },

  /**
   * 获取球杆详情
   */
  async getCueDetail(cueId) {
    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'getCueDetail',
          data: { cueId }
        })
        return res.result || res
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }

    const cue = mockData.cues.find(c => c.id === cueId)
    return mockRequest({ success: true, data: cue })
  }
}

// ============ 会员服务 ============
const memberService = {
  /**
   * 获取会员信息
   */
  async getMemberInfo() {
    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'getUserInfo',
          data: { openid: getOpenId() }
        })
        return res.result || res
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }

    return mockRequest({ success: true, data: mockData.memberInfo })
  },

  /**
   * 获取会员套餐
   */
  async getMemberPackages() {
    if (API_CONFIG.useCloud) {
      try {
        const res = await wx.cloud.callFunction({
          name: 'getMemberPackages'
        })
        return res.result || res
      } catch (err) {
        console.warn('云函数调用失败，使用mock')
      }
    }

    return mockRequest({ success: true, data: mockData.memberPackages })
  },

  /**
   * 购买会员卡
   */
  async buyMemberCard(packageId) {
    const pkg = mockData.memberPackages.find(p => p.id === packageId)
    if (!pkg) return { success: false, error: '套餐不存在' }

    const memberInfo = {
      id: 'M' + Date.now(),
      memberLevel: 'normal',
      balance: pkg.giftBalance || 0,
      points: pkg.giftPoints || 0,
      cardNo: 'M' + Date.now(),
      discountRate: pkg.price >= 799 ? 0.85 : 0.9,
      createTime: new Date().toISOString(),
      expireTime: new Date(Date.now() + pkg.duration * 86400000).toISOString()
    }

    mockData.memberInfo = memberInfo
    return mockRequest({ success: true, data: memberInfo })
  }
}

// ============ 支付服务 ============
const payService = {
  /**
   * 发起微信支付
   */
  async requestPayment(params) {
    return new Promise((resolve, reject) => {
      wx.requestPayment({
        timeStamp: Date.now().toString(),
        nonceStr: 'random_' + Date.now(),
        package: 'prepay_id=mock',
        signType: 'MD5',
        paySign: 'mock_pay_sign',
        success: resolve,
        fail: reject
      })
    })
  }
}

module.exports = {
  loginService,
  tableService,
  orderService,
  cueService,
  memberService,
  payService,
  API_CONFIG,
  getOpenId
}

/**
 * 台球厅小程序 - 应用入口文件
 * 采用微信云开发模式，支持小程序和H5
 */

App({
  globalData: {
    userInfo: null,
    openId: '',
    isLoggedIn: false,
    // 价格配置
    priceConfig: {
      perHour: 30,
      minDuration: 1,
      discountThreshold: 100,
      memberDiscount: 0.9
    }
  },

  onLaunch() {
    // 小程序启动时的初始化
    console.log('台球厅小程序启动')
  }
})

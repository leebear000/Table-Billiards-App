/**
 * getOrders 云函数 - 获取订单列表
 * 功能：获取用户的历史订单，支持分页和筛选
 */
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;

/**
 * 云函数入口
 * @param {object} event - 请求参数
 * @param {string} event.openid - 用户openid
 * @param {string} [event.type] - 订单类型筛选（all/session/product）
 * @param {string} [event.status] - 订单状态筛选（all/pending/paid/completed/cancelled/refunded）
 * @param {number} [event.page] - 页码（默认1）
 * @param {number} [event.page_size] - 每页数量（默认20，最大50）
 */
exports.main = async (event, context) => {
  const {
    openid,
    type = 'all',
    status = 'all',
    page = 1,
    page_size = 20
  } = event;

  // 参数校验
  if (!openid) {
    return { success: false, error: '缺少用户标识' };
  }

  // 限制每页数量
  const limit = Math.min(Math.max(1, parseInt(page_size) || 20), 50);
  const skip = (Math.max(1, parseInt(page) || 1) - 1) * limit;

  try {
    // 构建查询条件
    const query = { openid };

    // 类型筛选
    if (type === 'session') {
      query.type = 'session';
    } else if (type === 'product') {
      query.type = 'product';
    }

    // 状态筛选
    if (status !== 'all') {
      query.status = status;
    }

    // 查询总数
    const countRes = await db.collection('orders')
      .where(query)
      .count();

    const total = countRes.total;

    // 查询订单列表
    const ordersRes = await db.collection('orders')
      .where(query)
      .orderBy('created_at', 'desc')
      .skip(skip)
      .limit(limit)
      .get();

    // 获取关联数据（商品信息、桌台信息）
    const orders = await Promise.all(ordersRes.data.map(async (order) => {
      let orderDetail = {
        order_id: order._id,
        order_no: order.order_no,
        type: order.type,
        status: order.status,
        amount: order.amount,
        actual_amount: order.actual_amount,
        discount_amount: order.discount_amount,
        pay_method: order.pay_method,
        pay_time: order.pay_time,
        created_at: order.created_at,
        updated_at: order.updated_at
      };

      // 时长订单：获取桌台信息
      if (order.type === 'session' && order.session_id) {
        try {
          const sessionRes = await db.collection('sessions').doc(order.session_id).get();
          if (sessionRes.data) {
            orderDetail.table_name = sessionRes.data.table_name;
            orderDetail.start_time = sessionRes.data.start_time;
            orderDetail.end_time = sessionRes.data.end_time;
            orderDetail.duration_minutes = sessionRes.data.duration_minutes;
            orderDetail.purchased_minutes = sessionRes.data.purchased_minutes;
          }
        } catch (e) {
          console.warn('获取会话信息失败:', e);
        }
      }

      // 商品订单：获取商品信息
      if (order.type === 'product' && order.product_id) {
        try {
          const productRes = await db.collection('products').doc(order.product_id).get();
          if (productRes.data) {
            orderDetail.product_name = productRes.data.name;
            orderDetail.product_category = productRes.data.category;
          }
        } catch (e) {
          console.warn('获取商品信息失败:', e);
        }
      }

      // 状态中文描述
      const statusNames = {
        'pending': '待支付',
        'paid': '已支付',
        'completed': '已完成',
        'cancelled': '已取消',
        'refunded': '已退款'
      };
      orderDetail.status_name = statusNames[order.status] || order.status;

      return orderDetail;
    }));

    return {
      success: true,
      data: {
        list: orders,
        total: total,
        page: parseInt(page),
        page_size: limit,
        total_pages: Math.ceil(total / limit)
      }
    };

  } catch (error) {
    console.error('getOrders云函数错误:', error);
    return {
      success: false,
      error: '服务器错误：' + error.message
    };
  }
};

/**
 * getUserInfo 云函数 - 获取用户信息
 * 功能：获取当前用户的详细信息和会员状态
 */
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();

/**
 * 云函数入口
 * @param {object} event - 请求参数
 * @param {string} event.openid - 用户openid
 */
exports.main = async (event, context) => {
  const { openid } = event;

  // 参数校验
  if (!openid) {
    return { success: false, error: '缺少用户标识' };
  }

  try {
    // 查询用户信息
    const userRes = await db.collection('users').where({ openid }).get();

    if (!userRes.data || userRes.data.length === 0) {
      return { success: false, error: '用户不存在' };
    }

    const user = userRes.data[0];

    // 查询用户会员卡信息
    const memberCardsRes = await db.collection('member_cards')
      .where({
        user_openid: openid,
        status: 'active',
        expire_time: db.command.gt(Date.now())
      })
      .get();

    // 计算会员等级名称
    const memberLevelNames = {
      0: '普通用户',
      1: '铜牌会员',
      2: '银牌会员',
      3: '金牌会员',
      4: '钻石会员'
    };

    // 格式化返回数据
    const userInfo = {
      openid: user.openid,
      nickname: user.nickname || '微信用户',
      avatar_url: user.avatar_url || '',
      phone: user.phone || '',
      member_level: user.member_level || 0,
      member_level_name: memberLevelNames[user.member_level] || '普通用户',
      balance: user.balance || 0,
      balance_display: ((user.balance || 0) / 100).toFixed(2),
      points: user.points || 0,
      created_at: user.created_at,
      member_cards: memberCardsRes.data.map(card => ({
        card_no: card.card_no,
        card_type_id: card.card_type_id,
        buy_time: card.buy_time,
        expire_time: card.expire_time,
        days_remaining: Math.max(0, Math.ceil((card.expire_time - Date.now()) / (1000 * 60 * 60 * 24)))
      }))
    };

    return {
      success: true,
      data: userInfo
    };

  } catch (error) {
    console.error('getUserInfo云函数错误:', error);
    return {
      success: false,
      error: '服务器错误：' + error.message
    };
  }
};

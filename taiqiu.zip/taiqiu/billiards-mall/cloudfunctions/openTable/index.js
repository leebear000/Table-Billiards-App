/**
 * openTable 云函数 - 开台/购买时长
 * 功能：选择桌台并购买时长，创建会话和订单
 */
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;

/**
 * 生成唯一订单号
 * @returns {string} 订单号，格式：ORD + 时间戳 + 4位随机数
 */
function generateOrderNo() {
  const timestamp = Date.now();
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `ORD${timestamp}${random}`;
}

/**
 * 验证用户余额是否充足
 * @param {string} openid - 用户openid
 * @param {number} amount - 所需金额（分）
 * @returns {object} 用户信息和验证结果
 */
async function validateAndDeductBalance(openid, amount) {
  const userRes = await db.collection('users').where({ openid }).get();

  if (!userRes.data || userRes.data.length === 0) {
    return { success: false, error: '用户不存在' };
  }

  const user = userRes.data[0];

  if (user.balance < amount) {
    return {
      success: false,
      error: `余额不足，需要${amount / 100}元，当前余额${user.balance / 100}元`
    };
  }

  // 扣减余额
  await db.collection('users').doc(user._id).update({
    data: {
      balance: _.inc(-amount),
      updated_at: Date.now()
    }
  });

  return { success: true, user };
}

/**
 * 云函数入口
 * @param {object} event - 请求参数
 * @param {string} event.openid - 用户openid
 * @param {string} event.table_id - 桌台ID
 * @param {number} event.minutes - 购买时长（分钟）
 * @param {string} event.pay_method - 支付方式（wechat/balance）
 */
exports.main = async (event, context) => {
  const { openid, table_id, minutes, pay_method = 'wechat' } = event;

  // 参数校验
  if (!openid) {
    return { success: false, error: '缺少用户标识' };
  }
  if (!table_id) {
    return { success: false, error: '缺少桌台ID' };
  }
  if (!minutes || minutes <= 0) {
    return { success: false, error: '购买时长必须大于0' };
  }

  try {
    // 1. 查询桌台信息
    const tableRes = await db.collection('tables').doc(table_id).get();

    if (!tableRes.data) {
      return { success: false, error: '桌台不存在' };
    }

    const table = tableRes.data;

    // 2. 检查桌台是否已被占用
    const activeSessionRes = await db.collection('sessions')
      .where({
        table_id: table_id,
        status: 'active'
      })
      .get();

    if (activeSessionRes.data && activeSessionRes.data.length > 0) {
      return { success: false, error: '该桌台正在使用中，请选择其他桌台' };
    }

    // 3. 计算费用
    const amount = Math.round((minutes / 60) * table.price_per_hour);

    // 4. 处理支付
    if (pay_method === 'balance') {
      const balanceResult = await validateAndDeductBalance(openid, amount);
      if (!balanceResult.success) {
        return balanceResult;
      }
    }

    // 5. 创建会话记录
    const now = Date.now();
    const sessionData = {
      table_id: table_id,
      table_name: table.name,
      openid: openid,
      start_time: now,
      end_time: null,
      duration_minutes: 0,
      purchased_minutes: minutes,
      remaining_minutes: minutes,
      amount: amount,
      status: pay_method === 'wechat' ? 'pending' : 'active',
      created_at: now
    };

    const sessionRes = await db.collection('sessions').add({
      data: sessionData
    });

    const session_id = sessionRes._id;

    // 6. 创建订单记录
    const order_no = generateOrderNo();
    const orderData = {
      order_no: order_no,
      openid: openid,
      type: 'session',
      session_id: session_id,
      amount: amount,
      actual_amount: amount,
      discount_amount: 0,
      points_deduct: 0,
      status: pay_method === 'wechat' ? 'pending' : 'paid',
      pay_time: pay_method === 'balance' ? now : null,
      pay_method: pay_method,
      created_at: now,
      updated_at: now
    };

    await db.collection('orders').add({
      data: orderData
    });

    // 7. 如果是余额支付，更新桌台状态
    if (pay_method === 'balance') {
      await db.collection('tables').doc(table_id).update({
        data: {
          status: 'occupied',
          current_session_id: session_id
        }
      });
    }

    return {
      success: true,
      data: {
        session_id: session_id,
        order_no: order_no,
        table_id: table_id,
        table_name: table.name,
        start_time: now,
        purchased_minutes: minutes,
        amount: amount,
        pay_method: pay_method,
        // 微信支付时返回预支付信息需要的参数
        need_pay: pay_method === 'wechat'
      }
    };

  } catch (error) {
    console.error('openTable云函数错误:', error);
    return {
      success: false,
      error: '服务器错误：' + error.message
    };
  }
};

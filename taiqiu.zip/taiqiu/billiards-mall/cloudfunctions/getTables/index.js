/**
 * getTables 云函数 - 获取桌台列表
 * 功能：获取所有桌台及其当前状态
 */
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();

/**
 * 云函数入口
 * @param {object} event - 请求参数
 * @param {string} [event.type] - 桌台类型筛选（可选）
 */
exports.main = async (event, context) => {
  try {
    // 构建查询条件
    const query = {
      status: db.command.neq('$removed') // 排除已删除的桌台
    };

    // 如果传入了类型筛选
    if (event.type) {
      query.type = event.type;
    }

    // 查询桌台列表
    const tablesRes = await db.collection('tables')
      .where(query)
      .orderBy('name', 'asc')
      .get();

    // 获取所有进行中的会话，用于计算剩余时间
    const now = Date.now();
    const sessionsRes = await db.collection('sessions')
      .where({
        status: 'active',
        end_time: null
      })
      .get();

    // 构建桌台状态映射
    const sessionMap = {};
    if (sessionsRes.data) {
      sessionsRes.data.forEach(session => {
        sessionMap[session.table_id] = {
          session_id: session._id,
          remaining_minutes: Math.max(0, Math.ceil(
            (session.start_time + session.purchased_minutes * 60 * 1000 - now) / 60000
          )),
          start_time: session.start_time,
          openid: session.openid
        };
      });
    }

    // 组装返回数据
    const tables = tablesRes.data.map(table => {
      const sessionInfo = sessionMap[table._id] || null;
      return {
        table_id: table._id,
        name: table.name,
        type: table.type,
        price_per_hour: table.price_per_hour,
        status: sessionInfo ? 'occupied' : table.status,
        current_session: sessionInfo
      };
    });

    return {
      success: true,
      data: tables
    };

  } catch (error) {
    console.error('getTables云函数错误:', error);
    return {
      success: false,
      error: '服务器错误：' + error.message
    };
  }
};

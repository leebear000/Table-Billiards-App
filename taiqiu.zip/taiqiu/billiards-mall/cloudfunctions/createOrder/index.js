/**
 * createOrder 云函数 - 创建商品订单
 * 功能：创建球杆等商品的购买/租赁订单
 */
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;

/**
 * 生成唯一订单号
 * @returns {string} 订单号，格式：PRD + 时间戳 + 4位随机数
 */
function generateOrderNo() {
  const timestamp = Date.now();
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `PRD${timestamp}${random}`;
}

/**
 * 验证并扣减余额
 * @param {string} openid - 用户openid
 * @param {number} amount - 所需金额（分）
 */
async function validateAndDeductBalance(openid, amount) {
  const userRes = await db.collection('users').where({ openid }).get();

  if (!userRes.data || userRes.data.length === 0) {
    return { success: false, error: '用户不存在' };
  }

  const user = userRes.data[0];

  if (user.balance < amount) {
    return {
      success: false,
      error: `余额不足，需要${(amount / 100).toFixed(2)}元，当前余额${(user.balance / 100).toFixed(2)}元`
    };
  }

  await db.collection('users').doc(user._id).update({
    data: {
      balance: _.inc(-amount),
      updated_at: Date.now()
    }
  });

  return { success: true, user };
}

/**
 * 云函数入口
 * @param {object} event - 请求参数
 * @param {string} event.openid - 用户openid
 * @param {string} event.product_id - 商品ID
 * @param {number} event.quantity - 购买数量（默认1）
 * @param {string} event.type - 订单类型（buy:购买, rent:租赁）
 * @param {number} event.rent_hours - 租赁时长（小时，租赁时必填）
 * @param {string} event.pay_method - 支付方式（wechat/balance）
 */
exports.main = async (event, context) => {
  const {
    openid,
    product_id,
    quantity = 1,
    type = 'buy',
    rent_hours,
    pay_method = 'wechat'
  } = event;

  // 参数校验
  if (!openid) {
    return { success: false, error: '缺少用户标识' };
  }
  if (!product_id) {
    return { success: false, error: '缺少商品ID' };
  }
  if (type === 'rent' && (!rent_hours || rent_hours <= 0)) {
    return { success: false, error: '租赁订单需要指定租赁时长' };
  }

  try {
    // 1. 查询商品信息
    const productRes = await db.collection('products').doc(product_id).get();

    if (!productRes.data) {
      return { success: false, error: '商品不存在' };
    }

    const product = productRes.data;

    // 检查商品状态
    if (product.status !== 'active') {
      return { success: false, error: '商品已下架' };
    }

    // 2. 计算订单金额
    let amount;
    if (type === 'buy') {
      amount = product.price * quantity;
    } else {
      amount = product.rent_price * rent_hours * quantity;
    }

    // 检查库存
    if (product.stock < quantity) {
      return { success: false, error: `库存不足，当前库存${product.stock}` };
    }

    // 3. 获取用户会员等级以计算折扣
    const userRes = await db.collection('users').where({ openid }).get();
    let discountRate = 1.0;
    if (userRes.data && userRes.data.length > 0) {
      const memberLevel = userRes.data[0].member_level;
      // 会员折扣：铜牌0.95，银牌0.9，金牌0.85
      const discountRates = { 0: 1.0, 1: 0.95, 2: 0.9, 3: 0.85 };
      discountRate = discountRates[memberLevel] || 1.0;
    }

    const discountAmount = Math.round(amount * (1 - discountRate));
    const actualAmount = amount - discountAmount;

    // 4. 处理支付
    if (pay_method === 'balance') {
      const balanceResult = await validateAndDeductBalance(openid, actualAmount);
      if (!balanceResult.success) {
        return balanceResult;
      }
    }

    const now = Date.now();
    const order_no = generateOrderNo();

    // 5. 创建订单记录
    const orderData = {
      order_no: order_no,
      openid: openid,
      type: 'product',
      product_id: product_id,
      quantity: quantity,
      amount: amount,
      actual_amount: actualAmount,
      discount_amount: discountAmount,
      points_deduct: 0,
      status: pay_method === 'wechat' ? 'pending' : 'paid',
      pay_time: pay_method === 'balance' ? now : null,
      pay_method: pay_method,
      extra_data: type === 'rent' ? { rent_hours } : null,
      created_at: now,
      updated_at: now
    };

    await db.collection('orders').add({
      data: orderData
    });

    // 6. 如果是余额支付，扣减库存
    if (pay_method === 'balance') {
      await db.collection('products').doc(product_id).update({
        data: {
          stock: _.inc(-quantity)
        }
      });
    }

    return {
      success: true,
      data: {
        order_no: order_no,
        product_name: product.name,
        type: type,
        quantity: quantity,
        amount: amount,
        discount_amount: discountAmount,
        actual_amount: actualAmount,
        pay_method: pay_method,
        need_pay: pay_method === 'wechat'
      }
    };

  } catch (error) {
    console.error('createOrder云函数错误:', error);
    return {
      success: false,
      error: '服务器错误：' + error.message
    };
  }
};

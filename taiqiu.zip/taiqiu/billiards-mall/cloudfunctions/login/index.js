/**
 * login 云函数 - 用户登录
 * 功能：微信登录，创建/更新用户记录
 */
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();

/**
 * 生成唯一订单号
 * @returns {string} 订单号，格式：LOGIN + 时间戳 + 4位随机数
 */
function generateLoginId() {
  const timestamp = Date.now();
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `LOGIN${timestamp}${random}`;
}

/**
 * 云函数入口
 * @param {object} event - 请求参数
 * @param {string} event.code - 微信登录code
 */
exports.main = async (event, context) => {
  const { code } = event;

  // 参数校验
  if (!code) {
    return {
      success: false,
      error: '缺少登录code参数'
    };
  }

  try {
    // 注意：微信云开发环境中，获取openid应通过 wx.getUserInfo 或前端传递
    // 实际生产环境中，建议前端通过 wx.login 获取 code 后传给云函数
    // 云函数内部无法直接使用 wx.login，需要前端配合

    // 如果前端传递了 openid（通过 wx.cloud.getUserInfo 获取）
    let openid = event.openid;

    if (!openid) {
      // 尝试通过用户信息获取 openid
      // 在实际环境中，前端应该先通过 wx.cloud.getUserInfo() 获取用户信息
      return {
        success: false,
        error: '缺少用户openid，请确保已获取用户授权'
      };
    }

    // 查询用户是否已存在
    const userRes = await db.collection('users').where({
      openid: openid
    }).get();

    let userInfo;
    const now = Date.now();

    if (userRes.data && userRes.data.length > 0) {
      // 用户已存在，更新登录信息
      userInfo = userRes.data[0];
      await db.collection('users').doc(userInfo._id).update({
        data: {
          updated_at: now
        }
      });
    } else {
      // 新用户，创建用户记录
      const newUser = {
        openid: openid,
        nickname: event.nickname || '微信用户',
        avatar_url: event.avatarUrl || '',
        phone: event.phone || '',
        member_level: 0,
        balance: 0,
        points: 0,
        created_at: now,
        updated_at: now
      };

      const addRes = await db.collection('users').add({
        data: newUser
      });

      userInfo = {
        _id: addRes._id,
        ...newUser
      };
    }

    return {
      success: true,
      data: {
        openid: userInfo.openid,
        userId: userInfo._id,
        nickname: userInfo.nickname,
        avatar_url: userInfo.avatar_url,
        member_level: userInfo.member_level,
        balance: userInfo.balance,
        points: userInfo.points,
        isNewUser: userRes.data.length === 0
      }
    };

  } catch (error) {
    console.error('login云函数错误:', error);
    return {
      success: false,
      error: '服务器错误：' + error.message
    };
  }
};

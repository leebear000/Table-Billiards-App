/**
 * closeTable 云函数 - 结账
 * 功能：结束使用时长，计算费用并生成订单
 */
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;

/**
 * 生成唯一订单号
 * @returns {string} 订单号，格式：CLS + 时间戳 + 4位随机数
 */
function generateOrderNo() {
  const timestamp = Date.now();
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `CLS${timestamp}${random}`;
}

/**
 * 云函数入口
 * @param {object} event - 请求参数
 * @param {string} event.openid - 用户openid
 * @param {string} event.session_id - 会话ID
 */
exports.main = async (event, context) => {
  const { openid, session_id } = event;

  // 参数校验
  if (!openid) {
    return { success: false, error: '缺少用户标识' };
  }
  if (!session_id) {
    return { success: false, error: '缺少会话ID' };
  }

  try {
    // 1. 查询会话信息
    const sessionRes = await db.collection('sessions').doc(session_id).get();

    if (!sessionRes.data) {
      return { success: false, error: '会话不存在' };
    }

    const session = sessionRes.data;

    // 验证会话所属用户
    if (session.openid !== openid) {
      return { success: false, error: '无权操作此会话' };
    }

    // 检查会话是否已结账
    if (session.status === 'completed') {
      return { success: false, error: '该会话已结账' };
    }

    // 2. 查询桌台信息计算费率
    const tableRes = await db.collection('tables').doc(session.table_id).get();
    const table = tableRes.data;
    const pricePerMinute = table.price_per_hour / 60;

    // 3. 计算实际使用时长
    const now = Date.now();
    const startTime = session.start_time;
    const actualMinutes = Math.ceil((now - startTime) / 60000); // 向上取整
    const purchasedMinutes = session.purchased_minutes;

    // 4. 计算费用
    let extraMinutes = 0;
    let extraAmount = 0;
    let totalAmount;

    if (actualMinutes > purchasedMinutes) {
      // 超出购买时长，按超出部分收费
      extraMinutes = actualMinutes - purchasedMinutes;
      extraAmount = Math.round(extraMinutes * pricePerMinute);
      totalAmount = session.amount + extraAmount;
    } else {
      // 未超出购买时长，按原价收费
      totalAmount = session.amount;
    }

    const paidAmount = session.amount; // 已支付金额
    const needPay = extraAmount; // 需要补缴金额

    // 5. 更新会话记录
    await db.collection('sessions').doc(session_id).update({
      data: {
        end_time: now,
        duration_minutes: actualMinutes,
        remaining_minutes: 0,
        amount: totalAmount,
        status: 'completed',
        updated_at: now
      }
    });

    // 6. 创建补缴订单（如果有额外费用）
    let orderNo = session_id; // 使用会话ID作为关联订单号

    if (extraAmount > 0) {
      orderNo = generateOrderNo();
      await db.collection('orders').add({
        data: {
          order_no: orderNo,
          openid: openid,
          type: 'session',
          session_id: session_id,
          amount: extraAmount,
          actual_amount: extraAmount,
          discount_amount: 0,
          points_deduct: 0,
          status: 'pending', // 待补缴
          pay_method: 'wechat',
          created_at: now,
          updated_at: now
        }
      });
    } else {
      // 无需补缴，更新原订单状态
      await db.collection('orders')
        .where({
          session_id: session_id,
          status: 'pending'
        })
        .update({
          data: {
            status: 'completed',
            pay_method: 'session_end',
            updated_at: now
          }
        });
    }

    // 7. 更新桌台状态为空闲
    await db.collection('tables').doc(session.table_id).update({
      data: {
        status: 'available',
        current_session_id: ''
      }
    });

    // 8. 计算本次消费积分（每消费1元得1积分）
    const pointsEarned = Math.floor(totalAmount / 100);
    if (pointsEarned > 0) {
      await db.collection('users').where({ openid }).update({
        data: {
          points: _.inc(pointsEarned),
          updated_at: now
        }
      });
    }

    return {
      success: true,
      data: {
        session_id: session_id,
        order_no: orderNo,
        table_name: session.table_name,
        start_time: startTime,
        end_time: now,
        actual_minutes: actualMinutes,
        purchased_minutes: purchasedMinutes,
        extra_minutes: extraMinutes,
        extra_amount: extraAmount,
        total_amount: totalAmount,
        paid_amount: paidAmount,
        need_pay: needPay,
        points_earned: pointsEarned
      }
    };

  } catch (error) {
    console.error('closeTable云函数错误:', error);
    return {
      success: false,
      error: '服务器错误：' + error.message
    };
  }
};

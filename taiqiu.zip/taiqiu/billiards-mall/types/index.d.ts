/**
 * TypeScript 类型定义文件
 * 定义小程序中使用的数据结构
 */

// 用户信息
interface UserInfo {
  openId: string
  nickname: string
  avatarUrl: string
  phone?: string
  createTime: string
}

// 桌台信息
interface TableInfo {
  id: string
  name: string           // 桌台名称，如"1号台"
  type: 'standard' | 'snooker' | 'american'  // 台球类型
  status: 'available' | 'occupied' | 'reserved'  // 状态
  pricePerHour: number   // 每小时价格
  imageUrl: string       // 桌台图片
  description?: string  // 描述
  currentUserId?: string // 当前使用用户ID（占用时）
  startTime?: string     // 开始使用时间（占用时）
}

// 时长订单
interface TimeOrder {
  id: string
  orderNo: string        // 订单编号
  tableId: string        // 桌台ID
  tableName: string      // 桌台名称
  userId: string         // 用户ID
  duration: number       // 购买时长（分钟）
  amount: number         // 订单金额
  status: 'pending' | 'paid' | 'using' | 'completed' | 'cancelled'  // 订单状态
  startTime?: string     // 开始时间
  endTime?: string       // 结束时间
  createTime: string     // 创建时间
  payTime?: string       // 支付时间
}

// 球杆商品
interface CueProduct {
  id: string
  name: string           // 球杆名称
  brand: string          // 品牌
  type: 'purchase' | 'rent'  // 购买或租赁
  price: number          // 价格（购买价或租金/小时）
  deposit?: number       // 押金（租赁时）
  imageUrl: string       // 商品图片
  description: string   // 商品描述
  stock: number          // 库存
  specs?: string[]       // 规格选项
}

// 商品订单
interface ProductOrder {
  id: string
  orderNo: string
  userId: string
  productId: string
  productName: string
  type: 'purchase' | 'rent'
  quantity: number
  amount: number
  deposit?: number       // 押金
  status: 'pending' | 'paid' | 'delivered' | 'completed' | 'refunded'
  rentStartTime?: string // 租赁开始时间
  rentEndTime?: string   // 租赁结束时间
  createTime: string
  payTime?: string
}

// 会员信息
interface MemberInfo {
  id: string
  userId: string
  memberLevel: 'normal' | 'silver' | 'gold' | 'platinum'  // 会员等级
  balance: number        // 余额
  points: number         // 积分
  cardNo: string          // 会员卡号
  discountRate: number   // 折扣率
  createTime: string
  expireTime?: string    // 过期时间
}

// 会员卡套餐
interface MemberPackage {
  id: string
  name: string
  price: number
  duration: number       // 有效期（天）
  benefits: string[]      // 权益列表
  giftBalance?: number   // 赠送余额
  giftPoints?: number    // 赠送积分
}

// 支付参数
interface PayParams {
  orderId: string
  orderNo: string
  amount: number
  description: string
}

// API响应格式
interface ApiResponse<T> {
  success: boolean
  data?: T
  message?: string
  code?: number
}

// 列表查询参数
interface ListQuery {
  page: number
  pageSize: number
  status?: string
  type?: string
}

// 分页结果
interface PaginatedResult<T> {
  list: T[]
  total: number
  page: number
  pageSize: number
  hasMore: boolean
}

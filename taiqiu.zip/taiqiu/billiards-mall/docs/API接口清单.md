# 台球厅小程序 MVP API 接口清单

## 一、接口概览

| 分类 | 接口数量 | 说明 |
|------|----------|------|
| 用户模块 | 4 | 登录、用户信息、会员状态 |
| 桌台模块 | 4 | 列表、详情、开台、结账 |
| 时长订单 | 5 | 创建、查询、延长、取消、退款 |
| 球杆商城 | 6 | 列表、详情、购物车、订单 |
| 会员模块 | 5 | 卡列表、开卡、充值、积分 |
| 支付模块 | 3 | 统一下单、支付回调、查询 |
| 消息模块 | 2 | 公告列表、详情 |
| **合计** | **29** | - |

---

## 二、用户模块

### 2.1 微信登录
```
POST /api/user/login
```
**请求参数：**
```json
{
  "code": "string"  // 微信授权 code
}
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "token": "string",
    "userInfo": {
      "userId": "string",
      "openid": "string",
      "nickname": "string",
      "avatarUrl": "string",
      "isMember": false,
      "balance": 0,
      "points": 0
    }
  }
}
```

### 2.2 获取用户信息
```
GET /api/user/info
```
**请求参数：** 无（通过 token 自动获取）
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "userId": "string",
    "openid": "string",
    "nickname": "string",
    "avatarUrl": "string",
    "phone": "string",
    "isMember": true,
    "memberInfo": {
      "cardName": "月卡",
      "balance": 50000,
      "points": 1000,
      "expireTime": "2026-05-16"
    }
  }
}
```

### 2.3 更新用户信息
```
PUT /api/user/update
```
**请求参数：**
```json
{
  "nickname": "string",
  "phone": "string",
  "avatarUrl": "string"
}
```
**响应：**
```json
{
  "code": 0,
  "message": "success"
}
```

### 2.4 获取会员状态
```
GET /api/user/member-status
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "isMember": true,
    "memberId": "string",
    "cardName": "年卡",
    "status": "active",
    "balance": 100000,
    "points": 5000,
    "expireTime": "2027-04-16"
  }
}
```

---

## 三、桌台模块

### 3.1 获取桌台列表
```
GET /api/tables/list
```
**请求参数：**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| status | string | 否 | 状态筛选：idle/occupied/reserved/all |

**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "tables": [
      {
        "id": "string",
        "tableNo": "A01",
        "tableType": "standard",
        "hourlyRate": 3000,
        "memberRate": 2500,
        "status": "idle",
        "position": "大厅左侧"
      }
    ],
    "total": 10,
    "idleCount": 6,
    "occupiedCount": 4
  }
}
```

### 3.2 获取桌台详情
```
GET /api/tables/:id
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": "string",
    "tableNo": "A01",
    "tableType": "standard",
    "hourlyRate": 3000,
    "memberRate": 2500,
    "status": "occupied",
    "position": "大厅左侧",
    "currentOrder": {
      "orderId": "string",
      "startTime": "2026-04-16 10:00:00",
      "elapsedMinutes": 65,
      "currentAmount": 3250
    }
  }
}
```

### 3.3 开台（创建时长订单）
```
POST /api/tables/:id/open
```
**请求参数：**
```json
{
  "durationMinutes": 60,
  "paymentMethod": "wechat",  // wechat/balance
  "couponId": "string"       // 可选
}
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "orderId": "string",
    "orderNo": "T20260416100001",
    "tableId": "string",
    "tableNo": "A01",
    "durationMinutes": 60,
    "amount": 3000,
    "payStatus": "unpaid",
    "expireTime": "2026-04-16T10:05:00"  // 支付过期时间
  }
}
```

### 3.4 获取实时桌台状态（轮询）
```
GET /api/tables/status
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "tables": [
      {
        "id": "string",
        "status": "occupied",
        "elapsedMinutes": 65,
        "currentAmount": 3250
      }
    ]
  }
}
```

---

## 四、时长订单模块

### 4.1 获取订单列表
```
GET /api/time-orders
```
**请求参数：**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| status | string | 否 | 状态筛选 |
| page | number | 否 | 页码，默认 1 |
| pageSize | number | 否 | 每页数量，默认 10 |

**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "orders": [...],
    "total": 100,
    "page": 1,
    "pageSize": 10
  }
}
```

### 4.2 获取订单详情
```
GET /api/time-orders/:id
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": "string",
    "orderNo": "T20260416100001",
    "tableId": "string",
    "tableNo": "A01",
    "status": "active",
    "startTime": "2026-04-16 10:00:00",
    "endTime": null,
    "durationMinutes": 60,
    "actualDurationMinutes": 65,
    "hourlyRate": 3000,
    "originalAmount": 3000,
    "discountAmount": 0,
    "finalAmount": 3250,
    "payStatus": "paid",
    "extendRecords": []
  }
}
```

### 4.3 延长时长
```
POST /api/time-orders/:id/extend
```
**请求参数：**
```json
{
  "extendMinutes": 30,
  "paymentMethod": "wechat"
}
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "extendMinutes": 30,
    "amount": 1500,
    "newExpireTime": "2026-04-16 11:35:00"
  }
}
```

### 4.4 结账
```
POST /api/time-orders/:id/checkout
```
**请求参数：** 无
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "orderId": "string",
    "actualDurationMinutes": 95,
    "totalAmount": 4750,
    "paidAmount": 3000,
    "needPay": 1750
  }
}
```

### 4.5 取消订单
```
POST /api/time-orders/:id/cancel
```
**响应：**
```json
{
  "code": 0,
  "message": "success"
}
```

---

## 五、球杆商城模块

### 5.1 获取球杆列表
```
GET /api/cues
```
**请求参数：**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| category | string | 否 | 分类：buy/rent/both |
| type | string | 否 | 类型：snooker/pool/both |
| keyword | string | 否 | 搜索关键词 |
| sortBy | string | 否 | 排序：price_asc/price_desc/create_time |
| page | number | 否 | 页码 |
| pageSize | number | 否 | 每页数量 |

### 5.2 获取球杆详情
```
GET /api/cues/:id
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": "string",
    "name": "黑标球杆",
    "category": "both",
    "type": "pool",
    "brand": "LP",
    "level": "professional",
    "price": 29900,
    "rentalPrice": 1000,
    "deposit": 5000,
    "stock": 10,
    "rentStock": 5,
    "images": ["url1", "url2"],
    "description": "...",
    "specs": {
      "length": "145cm",
      "weight": "550g",
      "material": "枫木"
    }
  }
}
```

### 5.3 获取购物车
```
GET /api/cart
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "items": [
      {
        "id": "string",
        "productId": "string",
        "name": "黑标球杆",
        "category": "rent",
        "price": 1000,
        "quantity": 1,
        "subtotal": 1000
      }
    ],
    "totalAmount": 1000,
    "totalDeposit": 5000
  }
}
```

### 5.4 添加到购物车
```
POST /api/cart/add
```
**请求参数：**
```json
{
  "productId": "string",
  "quantity": 1
}
```

### 5.5 更新购物车数量
```
PUT /api/cart/:itemId
```
**请求参数：**
```json
{
  "quantity": 2
}
```

### 5.6 删除购物车商品
```
DELETE /api/cart/:itemId
```

### 5.7 创建球杆订单
```
POST /api/cue-orders
```
**请求参数：**
```json
{
  "items": [
    {"productId": "string", "quantity": 1}
  ],
  "deliveryType": "self_pickup",
  "addressId": "string",     // 快递场景必填
  "couponId": "string"
}
```

---

## 六、会员模块

### 6.1 获取会员卡列表
```
GET /api/membership/cards
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "cards": [
      {
        "id": "string",
        "name": "月卡",
        "type": "monthly",
        "price": 9900,
        "durationDays": 30,
        "discountRate": 0.9,
        "pointsMultiplier": 1.5,
        "description": "..."
      }
    ]
  }
}
```

### 6.2 开通/购买会员卡
```
POST /api/membership/open
```
**请求参数：**
```json
{
  "cardId": "string",
  "paymentMethod": "wechat"
}
```

### 6.3 余额充值
```
POST /api/membership/recharge
```
**请求参数：**
```json
{
  "amount": 10000,  // 充值金额（分）
  "paymentMethod": "wechat"
}
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "rechargeAmount": 10000,
    "bonusAmount": 1000,
    "totalAmount": 11000
  }
}
```

### 6.4 获取积分记录
```
GET /api/membership/points
```
**请求参数：**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| type | string | 否 | 类型：all/earn/spend |

### 6.5 积分兑换
```
POST /api/membership/points/redeem
```
**请求参数：**
```json
{
  "productId": "string",
  "quantity": 1
}
```

---

## 七、支付模块

### 7.1 统一下单（微信支付）
```
POST /api/pay/unified
```
**请求参数：**
```json
{
  "orderType": "time_order",  // time_order/cue_order/membership/recharge
  "orderId": "string",
  "paymentMethod": "wechat"
}
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "paymentParams": {
      "appId": "wx...",
      "timeStamp": "...",
      "nonceStr": "...",
      "package": "prepay_id=...",
      "signType": "MD5",
      "paySign": "..."
    }
  }
}
```

### 7.2 支付回调
```
POST /api/pay/callback
```
微信支付完成后，微信服务器回调此接口。
**请求参数：** 微信支付回调报文

**响应：**
```json
{
  "code": "SUCCESS",
  "message": "OK"
}
```

### 7.3 查询支付状态
```
GET /api/pay/query/:orderId
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "orderId": "string",
    "payStatus": "paid",
    "payTime": "2026-04-16 10:05:00",
    "transactionId": "..."
  }
}
```

---

## 八、交易记录模块

### 8.1 获取交易记录
```
GET /api/transactions
```
**请求参数：**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| type | string | 否 | 类型筛选 |
| startDate | string | 否 | 开始日期 |
| endDate | string | 否 | 结束日期 |
| page | number | 否 | 页码 |
| pageSize | number | 否 | 每页数量 |

---

## 九、公告模块

### 9.1 获取公告列表
```
GET /api/announcements
```
**响应：**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "announcements": [
      {
        "id": "string",
        "title": "五一优惠活动",
        "type": "important",
        "isTop": true,
        "publishTime": "2026-04-16 09:00:00"
      }
    ]
  }
}
```

### 9.2 获取公告详情
```
GET /api/announcements/:id
```

---

## 十、通用响应格式

### 成功响应
```json
{
  "code": 0,
  "message": "success",
  "data": {}  // 或其他数据类型
}
```

### 错误响应
```json
{
  "code": 10001,
  "message": "错误描述",
  "data": null
}
```

### 错误码定义
| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| 10001 | 参数错误 |
| 10002 | 签名验证失败 |
| 20001 | 用户未登录 |
| 20002 | 用户不存在 |
| 30001 | 桌台不存在 |
| 30002 | 桌台不可用 |
| 30003 | 订单不存在 |
| 30004 | 订单状态不允许此操作 |
| 40001 | 余额不足 |
| 50001 | 会员卡不存在 |
| 50002 | 会员已过期 |
| 60001 | 支付失败 |
| 60002 | 支付超时 |

---

*文档版本：v1.0*
*最后更新：2026-04-16*

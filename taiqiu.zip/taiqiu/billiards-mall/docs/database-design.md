# 台球厅小程序 - 云数据库设计文档

## 1. 设计概述

本设计基于微信云开发，采用 NoSQL 文档数据库。集合间通过 `openid`（用户标识）和 `_id`（记录ID）进行关联。

---

## 2. 集合设计

### 2.1 users（用户表）

存储用户基本信息和会员数据。

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| _id | ObjectId | 是 | 记录ID（系统自动生成） |
| openid | string | 是 | 微信用户唯一标识（索引） |
| nickname | string | 否 | 用户昵称 |
| avatar_url | string | 否 | 头像URL |
| phone | string | 否 | 手机号 |
| member_level | number | 否 | 会员等级（0:普通, 1:铜牌, 2:银牌, 3:金牌） |
| balance | number | 否 | 账户余额（单位：分） |
| points | number | 否 | 积分余额 |
| created_at | number | 是 | 注册时间戳 |
| updated_at | number | 是 | 更新时间戳 |

**索引**：`openid`（唯一索引）

**说明**：
- balance 和 points 单位统一使用「分」，避免浮点精度问题
- 用户首次登录时自动创建记录

---

### 2.2 tables（桌台表）

存储台球桌台信息。

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| _id | ObjectId | 是 | 桌台ID |
| name | string | 是 | 桌台名称（如"1号台"、"VIP-01"） |
| type | string | 是 | 桌台类型（"standard": 标准台, "snooker": 斯诺克, "VIP": VIP台） |
| price_per_hour | number | 是 | 每小时价格（单位：分） |
| status | string | 是 | 状态（"available": 空闲, "occupied": 占用, "reserved": 预约） |
| current_session_id | string | 否 | 当前占用会话ID |
| created_at | number | 是 | 创建时间戳 |

**说明**：
- price_per_hour 可根据桌台类型设置不同价格
- status 由系统根据 sessions 动态更新

---

### 2.3 sessions（时长会话表）

存储开台记录，记录每次使用时长。

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| _id | ObjectId | 是 | 会话ID |
| table_id | string | 是 | 桌台ID（关联 tables._id） |
| table_name | string | 是 | 桌台名称（冗余存储） |
| openid | string | 是 | 用户openid |
| start_time | number | 是 | 开始时间戳 |
| end_time | number | 否 | 结束时间戳 |
| duration_minutes | number | 否 | 时长（分钟） |
| purchased_minutes | number | 是 | 购买时长（分钟） |
| remaining_minutes | number | 否 | 剩余时长（分钟） |
| amount | number | 是 | 消费金额（单位：分） |
| status | string | 是 | 状态（"active": 进行中, "completed": 已结账） |
| created_at | number | 是 | 创建时间戳 |

**索引**：
- `openid`（查询用户会话）
- `table_id`（查询桌台会话）
- `status`（查询进行中会话）

**说明**：
- 进行中的会话会实时更新 remaining_minutes
- 结账时计算实际消费金额

---

### 2.4 products（商品表）

存储球杆等商品信息。

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| _id | ObjectId | 是 | 商品ID |
| name | string | 是 | 商品名称 |
| category | string | 是 | 类别（"cue": 球杆, "accessory": 配件） |
| description | string | 否 | 商品描述 |
| images | array | 否 | 商品图片URL列表 |
| price | number | 是 | 售价（单位：分，购买时使用） |
| rent_price | number | 否 | 租赁价格（单位：分/小时，租赁时使用） |
| stock | number | 是 | 库存数量 |
| status | string | 是 | 状态（"active": 上架, "inactive": 下架） |
| created_at | number | 是 | 创建时间戳 |

---

### 2.5 orders（订单表）

存储所有订单记录（时长订单 + 商品订单）。

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| _id | ObjectId | 是 | 订单ID |
| order_no | string | 是 | 订单编号（唯一索引） |
| openid | string | 是 | 用户openid |
| type | string | 是 | 订单类型（"session": 时长订单, "product": 商品订单） |
| session_id | string | 否 | 时长会话ID（时长订单时填写） |
| product_id | string | 否 | 商品ID（商品订单时填写） |
| quantity | number | 否 | 数量（商品订单时使用） |
| amount | number | 是 | 订单金额（单位：分） |
| actual_amount | number | 否 | 实际支付金额（单位：分） |
| discount_amount | number | 否 | 优惠金额（单位：分） |
| points_deduct | number | 否 | 积分抵扣数量 |
| status | string | 是 | 状态（"pending": 待支付, "paid": 已支付, "completed": 已完成, "cancelled": 已取消, "refunded": 已退款） |
| pay_time | number | 否 | 支付时间戳 |
| pay_method | string | 否 | 支付方式（"wechat": 微信支付, "balance": 余额支付） |
| created_at | number | 是 | 创建时间戳 |
| updated_at | number | 是 | 更新时间戳 |

**索引**：
- `order_no`（唯一索引）
- `openid`（查询用户订单）
- `status`（查询特定状态订单）

---

### 2.6 member_cards（会员卡表）

存储会员卡类型和用户持有的会员卡。

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| _id | ObjectId | 是 | 记录ID |

#### 会员卡类型（管理员配置）

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| card_type_id | string | 是 | 会员卡类型ID |
| name | string | 是 | 卡种名称（如"月卡"、"季卡"） |
| price | number | 是 | 售价（单位：分） |
| duration_days | number | 是 | 有效期（天数） |
| discount_rate | number | 否 | 消费折扣率（如 0.9 表示9折） |
| points_rate | number | 否 | 积分倍率（如 1.5 表示1.5倍） |
| description | string | 否 | 卡种描述 |
| status | string | 是 | 状态（"active": 在售, "inactive": 停售） |

#### 用户持有的会员卡

| 字段名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| user_openid | string | 是 | 用户openid |
| card_type_id | string | 是 | 会员卡类型ID |
| card_no | string | 是 | 会员卡号（唯一） |
| buy_time | number | 是 | 购买时间戳 |
| expire_time | number | 是 | 过期时间戳 |
| status | string | 是 | 状态（"active": 有效, "expired": 已过期） |

**说明**：使用 `card_type_id` 区分卡种配置和用户持有的卡

---

## 3. 云函数设计

### 3.1 login（用户登录）

**功能**：微信登录，创建/更新用户记录

**入参**：
```json
{
  "code": "微信登录code"
}
```

**出参**：
```json
{
  "success": true,
  "data": {
    "openid": "xxx",
    "userInfo": { /* 用户信息 */ }
  }
}
```

---

### 3.2 getTables（获取桌台列表）

**功能**：获取所有桌台及其当前状态

**入参**：
```json
{}
```

**出参**：
```json
{
  "success": true,
  "data": [
    {
      "_id": "xxx",
      "name": "1号台",
      "type": "standard",
      "price_per_hour": 3000,
      "status": "available"
    }
  ]
}
```

---

### 3.3 openTable（开台/购买时长）

**功能**：选择桌台并购买时长，开始计时

**入参**：
```json
{
  "table_id": "桌台ID",
  "minutes": 60,
  "pay_method": "wechat" | "balance"
}
```

**出参**：
```json
{
  "success": true,
  "data": {
    "session_id": "xxx",
    "order_no": "xxx",
    "table_name": "1号台",
    "start_time": 1713254400000,
    "purchased_minutes": 60,
    "amount": 3000
  }
}
```

---

### 3.4 closeTable（结账）

**功能**：结束使用时长，计算费用并生成订单

**入参**：
```json
{
  "session_id": "会话ID"
}
```

**出参**：
```json
{
  "success": true,
  "data": {
    "order_no": "xxx",
    "actual_minutes": 75,
    "purchased_minutes": 60,
    "extra_minutes": 15,
    "extra_amount": 750,
    "total_amount": 3750,
    "paid_amount": 3000,
    "need_pay": 750
  }
}
```

---

### 3.5 createOrder（创建商品订单）

**功能**：创建球杆等商品的购买/租赁订单

**入参**：
```json
{
  "product_id": "商品ID",
  "quantity": 1,
  "type": "buy" | "rent",
  "rent_hours": 2,
  "pay_method": "wechat" | "balance"
}
```

**出参**：
```json
{
  "success": true,
  "data": {
    "order_no": "xxx",
    "amount": 5000
  }
}
```

---

### 3.6 getUserInfo（获取用户信息）

**功能**：获取当前用户详细信息

**入参**：
```json
{}
```

**出参**：
```json
{
  "success": true,
  "data": {
    "openid": "xxx",
    "nickname": "张三",
    "avatar_url": "https://...",
    "member_level": 1,
    "balance": 10000,
    "points": 500
  }
}
```

---

### 3.7 getOrders（获取订单列表）

**功能**：获取用户的历史订单

**入参**：
```json
{
  "type": "all" | "session" | "product",
  "status": "all" | "pending" | "paid" | "completed",
  "page": 1,
  "page_size": 20
}
```

**出参**：
```json
{
  "success": true,
  "data": {
    "list": [ /* 订单列表 */ ],
    "total": 100,
    "page": 1,
    "page_size": 20
  }
}
```

---

## 4. 支付流程

### 4.1 微信支付流程

```
1. 前端调用云函数创建订单
2. 云函数调用 wx.cloud.callContainer 获取预支付ID
3. 前端调起微信支付
4. 微信支付回调云函数
5. 云函数更新订单状态
```

### 4.2 支付回调处理

支付回调云函数需验证签名并更新：
- orders 表的 status → "paid"
- sessions 表的 status → "active"
- users 表的 balance/points（如有变动）

---

*文档版本：v1.0*
*最后更新：2026-04-16*

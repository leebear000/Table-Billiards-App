# 台球厅小程序

基于微信云开发的台球厅管理小程序 MVP，支持小程序和 H5。

## 功能模块

- **首页**：场馆信息、桌台状态、快速开台
- **桌台管理**：查看桌台列表、桌台状态（空闲/占用/预约）
- **时长购买**：选择桌台、计时购买、费用预览
- **球杆商城**：球杆展示、购买、租赁
- **会员中心**：会员卡购买、余额查询、积分体系
- **订单中心**：订单列表、订单详情

## 技术栈

- **前端框架**：微信小程序 + Vant Weapp
- **后端**：微信云开发（云函数 + 云数据库）
- **支付**：微信支付

## 项目结构

```
billiards-mall/
├── app.js              # 应用入口
├── app.json            # 全局配置
├── app.wxss            # 全局样式
├── types/              # TypeScript 类型定义
├── utils/              # 工具函数
├── services/          # API 服务封装
├── assets/            # 静态资源
│   ├── icons/         # TabBar 图标
│   └── images/       # 图片资源
└── pages/             # 页面
    ├── home/          # 首页
    ├── tables/        # 桌台列表
    ├── time-purchase/ # 时长购买
    ├── cue-shop/      # 球杆商城
    ├── cue-detail/    # 球杆详情
    ├── member-center/ # 会员中心
    ├── my-orders/     # 我的订单
    └── order-detail/  # 订单详情
```

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 配置云开发环境

1. 登录 [微信公众平台](https://mp.weixin.qq.com/)
2. 开通云开发服务
3. 在 `project.config.json` 中配置 `appid`

### 3. 启动开发

使用微信开发者工具打开项目目录即可。

### 4. 云函数部署

将 `cloud/` 目录下的云函数部署到微信云开发环境。

## API 接口

| 云函数 | 功能 |
|--------|------|
| login | 用户登录 |
| getTables | 获取桌台列表 |
| openTable | 开台 |
| closeTable | 结账 |
| createOrder | 创建商品订单 |
| getOrders | 获取订单列表 |
| getUserInfo | 获取用户/会员信息 |
| getCueList | 获取球杆列表 |

## 开发说明

### Mock 数据

开发阶段默认使用 mock 数据，可在 `services/api.js` 中设置：

```javascript
API_CONFIG.useCloud = false  // 使用 mock 数据
API_CONFIG.useCloud = true   // 使用云函数
```

### 切换 TabBar

TabBar 页面需要在 `app.json` 的 `tabBar.list` 中配置，当前配置：

- 首页 (`/pages/home/index`)
- 球杆 (`/pages/cue-shop/index`)
- 会员 (`/pages/member-center/index`)
- 订单 (`/pages/my-orders/index`)

## 注意事项

1. 微信支付需要在商户平台开通Native支付
2. 云函数需要部署到对应的云开发环境
3. 图片资源请替换为真实图片

## License

MIT

/**
 * 时长购买页
 */
const { tableService, orderService, memberService, payService } = require('../../services/api.js')
const { formatDuration } = require('../../utils/util.js')

Page({
  data: {
    tableId: '',
    tableName: '',
    table: null,
    pricePerHour: 30,
    selectedDuration: 60,  // 默认1小时
    customDuration: 1,
    durationOptions: [
      { value: 60, label: '1小时', price: 30 },
      { value: 120, label: '2小时', price: 60 },
      { value: 180, label: '3小时', price: 90 },
      { value: 300, label: '5小时', price: 150 },
      { value: 480, label: '8小时', price: 240 }
    ],
    isMember: false,
    memberDiscount: 1,
    originalAmount: 30,
    discountAmount: 0,
    totalAmount: 30
  },

  onLoad(options) {
    this.setData({
      tableId: options.tableId || '',
      tableName: options.tableName || '未知桌台'
    })
    this.loadTableInfo()
    this.loadMemberInfo()
    this.calculateAmount()
  },

  async loadTableInfo() {
    if (!this.data.tableId) return
    try {
      const res = await tableService.getTableDetail(this.data.tableId)
      if (res.success && res.data) {
        this.setData({
          table: res.data,
          pricePerHour: res.data.pricePerHour
        })
        this.calculateAmount()
      }
    } catch (err) {
      console.error('加载桌台信息失败:', err)
    }
  },

  async loadMemberInfo() {
    // 模拟获取会员信息
    try {
      const res = await memberService.getMemberInfo('mock_user')
      if (res.success && res.data) {
        this.setData({
          isMember: true,
          memberDiscount: res.data.discountRate || 0.9
        })
        this.calculateAmount()
      }
    } catch (err) {
      // 非会员
    }
  },

  onSelectDuration(e) {
    const duration = e.currentTarget.dataset.duration
    this.setData({
      selectedDuration: duration,
      customDuration: duration / 60
    })
    this.calculateAmount()
  },

  onCustomDurationChange(e) {
    const hours = e.detail
    const duration = hours * 60
    this.setData({
      selectedDuration: duration,
      customDuration: hours
    })
    this.calculateAmount()
  },

  calculateAmount() {
    const { pricePerHour, selectedDuration, memberDiscount } = this.data
    const hours = selectedDuration / 60
    const original = pricePerHour * hours
    const discount = original * (1 - memberDiscount)
    const total = original * memberDiscount

    this.setData({
      originalAmount: original.toFixed(2),
      discountAmount: discount.toFixed(2),
      totalAmount: total.toFixed(2),
      displayDuration: formatDuration(selectedDuration)
    })
  },

  goToMember() {
    wx.showToast({ title: '请到会员中心开通', icon: 'none' })
  },

  async onSubmit() {
    wx.showLoading({ title: '创建订单...' })

    try {
      // 创建订单
      const res = await orderService.createTimeOrder({
        tableId: this.data.tableId,
        duration: this.data.selectedDuration,
        userId: 'mock_user'
      })

      if (res.success && res.data) {
        // 发起支付
        await payService.requestPayment({
          orderId: res.data.id,
          orderNo: res.data.orderNo,
          amount: res.data.amount,
          description: `${this.data.tableName} ${this.data.displayDuration}`
        })

        wx.hideLoading()
        wx.showToast({ title: '开台成功', icon: 'success' })

        // 跳转到订单详情
        setTimeout(() => {
          wx.redirectTo({
            url: `/pages/order-detail/index?orderId=${res.data.id}&type=time`
          })
        }, 1500)
      }
    } catch (err) {
      wx.hideLoading()
      console.error('开台失败:', err)
      wx.showToast({ title: '开台失败，请重试', icon: 'none' })
    }
  }
})

/**
 * 会员中心页
 */
const { memberService, payService } = require('../../services/api.js')
const app = getApp()

Page({
  data: {
    userInfo: null,
    memberInfo: null,
    packages: [],
    selectedPackage: 'P001',
    selectedPackageName: '',
    levelMap: {
      normal: '普通会员',
      silver: '银卡会员',
      gold: '金卡会员',
      platinum: '白金会员'
    }
  },

  onLoad() {
    this.setData({
      userInfo: app.globalData.userInfo
    })
    this.loadData()
  },

  onShow() {
    this.loadData()
  },

  async loadData() {
    try {
      // 加载会员套餐
      const packagesRes = await memberService.getMemberPackages()
      if (packagesRes.success && packagesRes.data) {
        const packages = packagesRes.data
        const selectedPackage = packages[0]
        this.setData({
          packages,
          selectedPackage: selectedPackage.id,
          selectedPackageName: selectedPackage.name
        })
      }

      // 加载会员信息
      const memberRes = await memberService.getMemberInfo('mock_user')
      if (memberRes.success && memberRes.data) {
        this.setData({ memberInfo: memberRes.data })
      }
    } catch (err) {
      console.error('加载会员数据失败:', err)
    }
  },

  onSelectPackage(e) {
    const packageId = e.currentTarget.dataset.packageId
    const pkg = this.data.packages.find(p => p.id === packageId)
    if (pkg) {
      this.setData({
        selectedPackage: packageId,
        selectedPackageName: pkg.name
      })
    }
  },

  async onOpenMember() {
    const pkg = this.data.packages.find(p => p.id === this.data.selectedPackage)
    if (!pkg) return

    wx.showLoading({ title: '创建订单...' })

    try {
      const res = await memberService.buyMemberCard({
        userId: 'mock_user',
        packageId: this.data.selectedPackage
      })

      if (res.success && res.data) {
        await payService.requestPayment({
          orderId: res.data.id,
          orderNo: res.data.orderNo,
          amount: pkg.price * 100, // 转为分
          description: `开通${pkg.name}`
        })

        wx.hideLoading()
        wx.showToast({ title: '开通成功', icon: 'success' })
        this.setData({ memberInfo: res.data })
      }
    } catch (err) {
      wx.hideLoading()
      console.error('开通会员失败:', err)
      wx.showToast({ title: '开通失败，请重试', icon: 'none' })
    }
  }
})

/**
 * 首页逻辑
 */
const { tableService, cueService } = require('../../services/api.js')
const app = getApp()

Page({
  data: {
    stats: {
      total: 6,
      available: 4,
      occupied: 1,
      reserved: 1
    },
    availableTables: [],
    hotCues: [],
    typeMap: {
      standard: '标准台',
      snooker: '斯诺克',
      american: '美式'
    }
  },

  onLoad() {
    this.loadData()
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.loadData()
  },

  /**
   * 加载页面数据
   */
  async loadData() {
    try {
      // 获取桌台列表
      const tablesRes = await tableService.getTableList()
      if (tablesRes.success && tablesRes.data) {
        const tables = tablesRes.data
        const available = tables.filter(t => t.status === 'available')
        const occupied = tables.filter(t => t.status === 'occupied')
        const reserved = tables.filter(t => t.status === 'reserved')

        this.setData({
          availableTables: available.slice(0, 4), // 只显示前4个
          stats: {
            total: tables.length,
            available: available.length,
            occupied: occupied.length,
            reserved: reserved.length
          }
        })
      }

      // 获取热门球杆
      const cuesRes = await cueService.getCueList()
      if (cuesRes.success && cuesRes.data) {
        this.setData({
          hotCues: cuesRes.data.slice(0, 3) // 只显示前3个
        })
      }
    } catch (err) {
      console.error('加载数据失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  /**
   * 快速开台 - 选择第一个空闲桌台
   */
  onQuickStart() {
    const tables = this.data.availableTables
    if (tables.length === 0) {
      wx.showToast({ title: '暂无可用桌台', icon: 'none' })
      return
    }
    wx.navigateTo({
      url: `/pages/time-purchase/index?tableId=${tables[0].id}&tableName=${tables[0].name}`
    })
  },

  /**
   * 查看全部桌台
   */
  goToTables() {
    wx.navigateTo({ url: '/pages/tables/index' })
  },

  /**
   * 跳转球杆商城
   */
  goToCueShop() {
    wx.switchTab({ url: '/pages/cue-shop/index' })
  },

  /**
   * 跳转会员中心
   */
  goToMember() {
    wx.switchTab({ url: '/pages/member-center/index' })
  },

  /**
   * 选择桌台开台
   */
  onSelectTable(e) {
    const table = e.currentTarget.dataset.table
    wx.navigateTo({
      url: `/pages/time-purchase/index?tableId=${table.id}&tableName=${table.name}`
    })
  },

  /**
   * 选择球杆
   */
  onSelectCue(e) {
    const cue = e.currentTarget.dataset.cue
    wx.navigateTo({
      url: `/pages/cue-detail/index?cueId=${cue.id}`
    })
  },

  /**
   * 优惠券
   */
  onCoupon() {
    wx.showToast({ title: '优惠券功能开发中', icon: 'none' })
  },

  /**
   * 联系客服
   */
  onContact() {
    wx.showToast({ title: '客服电话：400-888-8888', icon: 'none' })
  }
})

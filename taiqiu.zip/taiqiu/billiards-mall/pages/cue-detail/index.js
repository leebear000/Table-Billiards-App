/**
 * 球杆详情页
 */
const { cueService, orderService, payService } = require('../../services/api.js')

Page({
  data: {
    cueId: '',
    cue: null,
    selectedHours: 1,
    rentOptions: [
      { hours: 1, label: '1小时', price: 0 },
      { hours: 2, label: '2小时', price: 0 },
      { hours: 4, label: '4小时', price: 0 },
      { hours: 8, label: '8小时', price: 0 }
    ],
    totalRent: 0,
    totalPrice: 0
  },

  onLoad(options) {
    this.setData({ cueId: options.cueId || '' })
    this.loadCueDetail()
  },

  async loadCueDetail() {
    try {
      const res = await cueService.getCueDetail(this.data.cueId)
      if (res.success && res.data) {
        const cue = res.data
        const rentOptions = this.data.rentOptions.map(opt => ({
          ...opt,
          price: cue.price * opt.hours
        }))
        this.setData({
          cue,
          rentOptions,
          totalRent: cue.price,
          totalPrice: cue.type === 'purchase' ? cue.price : cue.price + cue.deposit
        })
      }
    } catch (err) {
      console.error('加载球杆详情失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  onSelectHours(e) {
    const hours = e.currentTarget.dataset.hours
    const { cue } = this.data
    const rentPrice = cue.price * hours
    this.setData({
      selectedHours: hours,
      totalRent: rentPrice,
      totalPrice: rentPrice + cue.deposit
    })
  },

  async onSubmit() {
    const { cue, selectedHours } = this.data
    wx.showLoading({ title: '创建订单...' })

    try {
      // 创建商品订单
      const res = await orderService.createProductOrder({
        productId: cue.id,
        productName: cue.name,
        type: cue.type,
        quantity: 1,
        rentHours: cue.type === 'rent' ? selectedHours : undefined
      })

      if (res.success && res.data) {
        // 发起支付
        const totalAmount = cue.type === 'purchase'
          ? cue.price
          : cue.price * selectedHours + cue.deposit

        await payService.requestPayment({
          orderId: res.data.id,
          orderNo: res.data.orderNo,
          amount: totalAmount,
          description: `${cue.name} ${cue.type === 'rent' ? '租赁' : '购买'}`
        })

        wx.hideLoading()
        wx.showToast({ title: '下单成功', icon: 'success' })

        setTimeout(() => {
          wx.redirectTo({
            url: `/pages/order-detail/index?orderId=${res.data.id}&type=product`
          })
        }, 1500)
      }
    } catch (err) {
      wx.hideLoading()
      console.error('下单失败:', err)
      wx.showToast({ title: '下单失败，请重试', icon: 'none' })
    }
  }
})

/**
 * 球杆商城页
 */
const { cueService } = require('../../services/api.js')

Page({
  data: {
    allCues: [],
    cues: [],
    activeTab: 'all'
  },

  onLoad() {
    this.loadCues()
  },

  async loadCues() {
    try {
      const res = await cueService.getCueList()
      if (res.success && res.data) {
        this.setData({
          allCues: res.data,
          cues: res.data
        })
      }
    } catch (err) {
      console.error('加载球杆列表失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  onTabChange(e) {
    const tab = e.detail.name
    this.setData({ activeTab: tab })
    this.filterCues(tab)
  },

  filterCues(tab) {
    const { allCues } = this.data
    if (tab === 'all') {
      this.setData({ cues: allCues })
    } else {
      this.setData({ cues: allCues.filter(c => c.type === tab) })
    }
  },

  goToDetail(e) {
    const cueId = e.currentTarget.dataset.cueId
    wx.navigateTo({
      url: `/pages/cue-detail/index?cueId=${cueId}`
    })
  }
})

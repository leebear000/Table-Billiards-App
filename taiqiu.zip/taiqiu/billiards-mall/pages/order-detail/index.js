/**
 * 订单详情页
 */
const { orderService } = require('../../services/api.js')
const { formatDuration, formatDate } = require('../../utils/util.js')

Page({
  data: {
    orderId: '',
    orderType: 'time',
    order: null,
    statusText: '',
    usingDuration: '0分钟'
  },

  onLoad(options) {
    this.setData({
      orderId: options.orderId || '',
      orderType: options.type || 'time'
    })
    this.loadOrderDetail()
  },

  async loadOrderDetail() {
    try {
      const { orderType, orderId } = this.data

      if (orderType === 'time') {
        const res = await orderService.getTimeOrders('mock_user')
        if (res.success && res.data) {
          const order = res.data.find(o => o.id === orderId)
          if (order) {
            this.setData({
              order,
              statusText: this.getStatusText('time', order.status)
            })
            // 如果正在使用，计算已用时长
            if (order.status === 'using' && order.startTime) {
              this.updateUsingDuration(order.startTime)
            }
          }
        }
      } else {
        const res = await orderService.getProductOrders('mock_user')
        if (res.success && res.data) {
          const order = res.data.find(o => o.id === orderId)
          if (order) {
            this.setData({
              order,
              statusText: this.getStatusText('product', order.status)
            })
          }
        }
      }
    } catch (err) {
      console.error('加载订单详情失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  getStatusText(type, status) {
    const statusMap = {
      time: {
        pending: '待支付',
        paid: '已支付',
        using: '使用中',
        completed: '已完成',
        cancelled: '已取消'
      },
      product: {
        pending: '待支付',
        paid: '已支付',
        delivered: '待收货',
        completed: '已完成',
        refunded: '已退款'
      }
    }
    return statusMap[type]?.[status] || status
  },

  updateUsingDuration(startTime) {
    const now = new Date()
    const start = new Date(startTime)
    const diff = Math.floor((now - start) / 60000) // 分钟
    this.setData({ usingDuration: formatDuration(diff) })
  },

  onExtendTime() {
    wx.showToast({ title: '延长时长功能开发中', icon: 'none' })
  },

  async onCheckout() {
    wx.showModal({
      title: '确认结账',
      content: '确定要结账离开吗？',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '处理中...' })
          try {
            const res = await orderService.checkout(this.data.orderId)
            if (res.success) {
              wx.hideLoading()
              wx.showToast({ title: '结账成功', icon: 'success' })
              setTimeout(() => {
                wx.navigateBack()
              }, 1500)
            }
          } catch (err) {
            wx.hideLoading()
            wx.showToast({ title: '结账失败', icon: 'none' })
          }
        }
      }
    })
  }
})

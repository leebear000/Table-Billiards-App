/**
 * 我的订单页
 */
const { orderService } = require('../../services/api.js')

Page({
  data: {
    activeTab: 'all',
    timeOrders: [],
    productOrders: [],
    statusMap: {
      time: {
        pending: '待支付',
        paid: '已支付',
        using: '使用中',
        completed: '已完成',
        cancelled: '已取消'
      },
      product: {
        pending: '待支付',
        paid: '已支付',
        delivered: '待收货',
        completed: '已完成',
        refunded: '已退款'
      }
    }
  },

  onShow() {
    this.loadOrders()
  },

  async loadOrders() {
    try {
      // 加载时长订单
      const timeRes = await orderService.getTimeOrders('mock_user')
      if (timeRes.success && timeRes.data) {
        this.setData({ timeOrders: timeRes.data })
      }

      // 加载商品订单
      const productRes = await orderService.getProductOrders('mock_user')
      if (productRes.success && productRes.data) {
        this.setData({ productOrders: productRes.data })
      }
    } catch (err) {
      console.error('加载订单失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  onTabChange(e) {
    this.setData({ activeTab: e.detail.name })
  },

  goToDetail(e) {
    const { orderId, type } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/order-detail/index?orderId=${orderId}&type=${type}`
    })
  }
})

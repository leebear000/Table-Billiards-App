/**
 * 桌台列表页
 */
const { tableService } = require('../../services/api.js')

Page({
  data: {
    tables: [],
    filteredTables: [],
    activeTab: 'all',
    typeMap: {
      standard: '标准台',
      snooker: '斯诺克',
      american: '美式'
    },
    statusTextMap: {
      available: '空闲',
      occupied: '占用',
      reserved: '预约'
    },
    statusTypeMap: {
      available: 'success',
      occupied: 'danger',
      reserved: 'warning'
    }
  },

  onLoad() {
    this.loadTables()
  },

  onShow() {
    this.loadTables()
  },

  async loadTables() {
    try {
      const res = await tableService.getTableList()
      if (res.success && res.data) {
        this.setData({ tables: res.data })
        this.filterTables()
      }
    } catch (err) {
      console.error('加载桌台失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  onTabChange(e) {
    this.setData({ activeTab: e.detail.name })
    this.filterTables()
  },

  filterTables() {
    const { tables, activeTab } = this.data
    if (activeTab === 'all') {
      this.setData({ filteredTables: tables })
    } else {
      this.setData({ filteredTables: tables.filter(t => t.status === activeTab) })
    }
  },

  onSelectTable(e) {
    const table = e.currentTarget.dataset.table
    if (table.status !== 'available') {
      wx.showToast({ title: '该桌台不可用', icon: 'none' })
      return
    }
    wx.navigateTo({
      url: `/pages/time-purchase/index?tableId=${table.id}&tableName=${table.name}`
    })
  }
})
